#include<iostream>
#include<string>
using namespace std;
//hossein_nikbakht
class kasr
{
public:
	int surat, makhraj;
	kasr(int s,int m) {
		cout << "Enter surat: ";
		cin >> s;
		surat = s;
		cout << "Enter makhraj: ";
		cin >> m;
		makhraj = m;
	}
	void show(string name) {
		if (makhraj == 1)
			cout << '\n' << name << ":" << surat << endl;
		else if (makhraj != 0)
			cout << '\n' << name << ":" << surat << "/" << makhraj << endl;
		else
			cout << "ERROR /0";
	}
	void sum(kasr kasr_digar);
	void tafrigh(kasr kasr_digar);
	void zarb(kasr kasr_digar);
	void tsghsim(kasr kasr_digar);
};

void kasr::sum(kasr kasr_digar)
{
	int s = this->surat*kasr_digar.makhraj + kasr_digar.surat*this->makhraj;
	int m = this->makhraj*kasr_digar.makhraj;

	cout << "\n sum: " << s << '/' << m << endl;
}

void kasr::tafrigh(kasr kasr_digar)
{
	int s = this->surat*kasr_digar.makhraj - kasr_digar.surat*this->makhraj;
	int m = this->makhraj*kasr_digar.makhraj;

	cout << "\n tafrigh: " << s << '/' << m << endl;
}

void kasr::zarb(kasr kasr_digar)
{
	int s = this->surat*kasr_digar.surat;
	int m = this->makhraj*kasr_digar.makhraj;

	cout << "\n zarb: " << s << '/' << m << endl;
}

void kasr::tsghsim(kasr kasr_digar)
{
	int s = this->surat*kasr_digar.makhraj;
	int m = this->makhraj*kasr_digar.surat;

	cout << "\n tsghsim: " << s << '/' << m << endl;
}


int main()
{
	cout << "kasr1: " << endl;
	kasr kasr1(0, 1);

	cout << "kasr2: " << endl;
	kasr kasr2(0, 1);

	kasr1.show("kasr1");
	kasr2.show("kasr2");

	kasr1.sum(kasr2);
	kasr1.tafrigh(kasr2);
	kasr1.zarb(kasr2);
	kasr1.tsghsim(kasr2);
    return 0;
}
