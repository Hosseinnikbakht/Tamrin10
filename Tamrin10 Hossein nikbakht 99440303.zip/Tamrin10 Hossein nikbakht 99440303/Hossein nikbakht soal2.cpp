#include<iostream>
#include<string>
using namespace std;
//hossein_nikbakht
class time
{
public:
	int hour, min, sec;
	time(int h,int m,int s) {
		cout << "Enter hour: ";
		cin >> h;
		hour = h;
		cout << "Enter min: ";
		cin >> m;
		min = m;
		cout << "Enter sec: ";
		cin >> s;
		sec = s;
	}
	void show(string name) {
		cout << '\n' << name << ":  " << hour << ":" << min << ":" << sec << endl;
	}
	void sum(time zaman_digar);
	void tafrigh(time zaman_digar);
	void time_to_sec();
	void sec_to_time();
};


void time::sum(time zaman_digar)
{
	int h = this->hour + zaman_digar.hour;
	int m = this->min + zaman_digar.min;
	if (m >= 60){
		h++;
		m -= 60;
	}
	int s = this->sec + zaman_digar.sec;
	if (s >= 60) {
		m++;
		s -= 60;
	}
	cout << "\n jam:  " << h << ":" << m << ":" << s << endl;
}

void time::tafrigh(time zaman_digar)
{
	int h = this->hour - zaman_digar.hour;
	int m = this->min - zaman_digar.min;
	if (m < 0) {
		h--;
		m += 60;
	}
	int s = this->sec - zaman_digar.sec;
	if (s < 0) {
		m--;
		s += 60;
	}
	cout << "\n tafrigh:  " << h << ":" << m << ":" << s << endl;
}

void time::time_to_sec()
{
	int se=0;
	se += this->hour * 3600;
	se += this->min * 60;
	se += this->sec;
	cout << "\n time to sec: " << se << endl;
}

void time::sec_to_time()
{
	int se;
	cout << "Enter secend:";
	cin >> se;
	int h = se / 3600;
	se = se % 3600;
	int m = se / 60;
	int s = se % 60;
	cout << "\n sec to time:  " << h << ":" << m << ":" << s << endl;
}


int main()
{
	cout << "zaman1: " << endl;
	time zaman1(0, 0, 0);

	cout << "zaman2: " << endl;
	time zaman2(0, 0, 0);

	zaman1.show("zaman1");
	zaman2.show("zaman2");

	zaman1.sum(zaman2);
	zaman1.tafrigh(zaman2);
	zaman1.time_to_sec();
	zaman1.sec_to_time();
	return 0;
}

